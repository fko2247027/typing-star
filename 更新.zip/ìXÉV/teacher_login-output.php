<link rel="stylesheet" href="mystyle.css">

<?php session_start(); ?>
<?php
unset($_SESSION['teacher_table']);
$pdo=new PDO('mysql:host=localhost;dbname=typingstar;charset=utf8', 
	'user', 'password');
$sql=$pdo->prepare('select * from teacher_table where teacher_number=? and teacher_password=?');
$sql->execute([$_REQUEST['name'], $_REQUEST['password']]);
foreach ($sql as $row) {
	$_SESSION['teacher_table']=[
		'name'=>$row['teacher_number'], 
		'password'=>$row['teacher_password']];
}
if (isset($_SESSION['teacher_table'])) {
	header("Location: top2.php");

	// echo 'ログイン完了しました。', $_SESSION['teacher_table']['name'], 'さん。';
	// echo '<br>';
	// URL指定（）
	echo '';
} else {
	echo 'ログイン名またはパスワードが違います。';
	echo '<br>';
	// URL指定（）
	echo '';
}
?>
<input type="submit" onclick="location.href='./teacher_login-input.php'" value="戻る">



