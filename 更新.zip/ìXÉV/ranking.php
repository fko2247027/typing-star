<link rel="stylesheet" href="ranking.css">

<hgroup>
<h2>ランキング</h2>
</hgroup>
<form action="" method="post">
<?php require "score.php" ;?>
<input type="button" onclick="location.href='./top2.php'" value="戻る">


</form>
