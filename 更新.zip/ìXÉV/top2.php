<link rel="stylesheet" href="mystyle.css">


<hgroup>
<h2>タイピング★スター</h2>
</hgroup>
<input type="submit" onclick="location.href='./typing1.php'" value="プレイ">
<input type="submit" onclick="location.href='./ranking.php'" value="ランキング">
<input type="submit" onclick="location.href='./logout-input.php'" value="ログアウト">
