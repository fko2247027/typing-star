<link rel="stylesheet" href="mystyle.css">
<hgroup>
<h2>ログアウトしますか？</h2>
</hgroup>

<input type="submit" onclick="location.href='./logout-output.php'" value="ログアウト">
<input type="submit" onclick="location.href='./top2.php'" value="戻る">

