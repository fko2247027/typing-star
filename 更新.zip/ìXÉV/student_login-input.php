<link rel="stylesheet" href="mystyle.css">

<h1>生徒ログイン画面</h1>
<input type="submit" onclick="location.href='./teacher_login-input.php'" value="管理者ログイン用">


<hgroup>
<h2>学籍番号とパスワードを入力してください。</h2>
</hgroup>
<form action="student_login-output.php" method="post">
<div class="group">
<input type="name" name="name"><span class="highlight"></span><span class="bar"></span>
<label>学籍番号</label>
</div>
<div class="group">
<input type="password" name="password"><span class="highlight"></span><span class="bar"></span>
<label>パスワード</label>
  </div>
<input type="submit" value="ログイン">

<input type="button" onclick="location.href='./top.php'" value="戻る">

</form>

