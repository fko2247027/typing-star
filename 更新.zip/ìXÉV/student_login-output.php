<link rel="stylesheet" href="mystyle.css">

<?php session_start(); ?>
<?php
unset($_SESSION['student_table']);
$pdo=new PDO('mysql:host=localhost;dbname=typingstar;charset=utf8', 
	'user', 'password');
$sql=$pdo->prepare('select * from student_table where student_number=? and student_password=?');
$sql->execute([$_REQUEST['name'], $_REQUEST['password']]);
foreach ($sql as $row) {
	$_SESSION['student_table']=[
		'name'=>$row['student_number'], 
		'password'=>$row['student_password']];
}
if (isset($_SESSION['student_table'])) {
	// echo 'ログイン完了しました。', $_SESSION['student_table']['name'], 'さん。';
	header("Location: top2.php");
	// echo '<br>';
	
	// URL指定（）
	echo '';
} else {
	echo 'ログイン名またはパスワードが違います。';
	echo '<br>';
	// URL指定（）
	echo '';
}
?>

<input type="submit" onclick="location.href='./student_login-input.php'" value="戻る">




