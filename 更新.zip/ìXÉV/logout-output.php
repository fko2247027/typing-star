<link rel="stylesheet" href="mystyle.css">

<?php session_start();?>

<?php
    if (isset($_SESSION['student_table'])) {
        unset($_SESSION['student_table']);
        echo 'ログアウトしました。';
    } else {
        echo 'すでにログアウトしています。';
    }
?>
<input type="submit" onclick="location.href='./top.php'" value="TOPへ戻る">

<!-- URL指定（メニュー画面） -->
