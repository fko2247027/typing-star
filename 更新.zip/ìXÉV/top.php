<link rel="stylesheet" href="mystyle.css">

<hgroup>
<h2>タイピング★スター</h2>
</hgroup>


<input type="submit" onclick="location.href='./student_login-input.php'" value="ログインしてプレイ">
<input type="submit" onclick="location.href='./typing1.php'" value="ログインせずにプレイ">


