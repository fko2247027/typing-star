<?php session_start(); ?>
<?php
unset($_SESSION['student_table']);
$pdo=new PDO('mysql:host=localhost;dbname=typingstar;charset=utf8', 
	'user', 'password');
$sql=$pdo->prepare('select * from student_table where student_name=? and student_password=?');
$sql->execute([$_REQUEST['name'], $_REQUEST['password']]);
foreach ($sql as $row) {
	$_SESSION['student_table']=[
		'name'=>$row['student_name'], 
		'password'=>$row['student_password']];
}
if (isset($_SESSION['student_table'])) {
	echo 'ログイン完了しました。', $_SESSION['student_table']['name'], 'さん。';
	echo '<br>';
	// URL指定（）
	echo '';
} else {
	echo 'ログイン名またはパスワードが違います。';
	echo '<br>';
	// URL指定（）
	echo '';
}
?>


