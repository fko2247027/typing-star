<p>ログアウトしますか？</p>
<a href="teacher_logout-output.php">ログアウト</a>