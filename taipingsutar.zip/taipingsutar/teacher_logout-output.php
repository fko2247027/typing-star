<?php session_start();?>

<?php
    if (isset($_SESSION['teacher_table'])) {
        unset($_SESSION['teacher_table']);
        echo 'ログアウトしました。';
    } else {
        echo 'すでにログアウトしています。';
    }
?>
<!-- URL指定（メニュー画面） -->
