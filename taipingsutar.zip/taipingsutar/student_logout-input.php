<p>ログアウトしますか？</p>
<a href="student_logout-output.php">ログアウト</a>