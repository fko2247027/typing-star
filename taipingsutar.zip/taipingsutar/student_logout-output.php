<?php session_start();?>

<?php
    if (isset($_SESSION['student_table'])) {
        unset($_SESSION['student_table']);
        echo 'ログアウトしました。';
    } else {
        echo 'すでにログアウトしています。';
    }
?>
<!-- URL指定（メニュー画面） -->
