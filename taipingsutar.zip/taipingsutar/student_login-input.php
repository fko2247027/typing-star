<p>名前を入力してください。</p>
<p>パスワードを入力してください。</p>
<form action="student_login-output.php" method="post">
<input type="name" name="name">
<input type="password" name="password">
<input type="submit" value="確定">
</form>
