<?php session_start(); ?>
<?php
unset($_SESSION['teacher_table']);
$pdo=new PDO('mysql:host=localhost;dbname=typingstar;charset=utf8', 
	'user', 'password');
$sql=$pdo->prepare('select * from teacher_table where teacher_name=? and teacher_password=?');
$sql->execute([$_REQUEST['name'], $_REQUEST['password']]);
foreach ($sql as $row) {
	$_SESSION['teacher_table']=[
		'name'=>$row['teacher_name'], 
		'password'=>$row['teacher_password']];
}
if (isset($_SESSION['teacher_table'])) {
	echo 'ログイン完了しました。', $_SESSION['teacher_table']['name'], 'さん。';
	echo '<br>';
	// URL指定（）
	echo '';
} else {
	echo 'ログイン名またはパスワードが違います。';
	echo '<br>';
	// URL指定（）
	echo '';
}
?>


