<link rel="stylesheet" href="login.css">
<input type="submit" value="管理者ログイン用">
<hgroup>
<h2>学籍番号とパスワードを入力してください。</h2>
</hgroup>
<form action="student_login-output.php" method="post">
<div class="group">
<input type="name" name="name"><span class="highlight"></span><span class="bar"></span>
<label>学籍番号</label>
</div>
<div class="group">
<input type="password" name="password"><span class="highlight"></span><span class="bar"></span>
<label>パスワード</label>
  </div>
<input type="submit" value="ログイン">
<input type="submit" value="戻る">
</form>
