<link rel="stylesheet" href="login.css">
<input type="submit" value="生徒ログイン用">
<hgroup>
<h2>IDとパスワードを入力してください。</h2>
</hgroup>
<form action="teacher_login-output.php" method="post">
<div class="group">
<input type="name" name="name"><span class="highlight"></span><span class="bar"></span>
<label>ID</label>
</div>
<div class="group">
<input type="password" name="password"><span class="highlight"></span><span class="bar"></span>
<label>パスワード</label>
  </div>
<input type="submit" value="ログイン">
<input type="submit" value="戻る">
</form>
